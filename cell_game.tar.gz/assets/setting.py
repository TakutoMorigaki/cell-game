STAGES = {
    1 : {"normal_cells": 100, "abnormal_cells": 1},
    2 : {"normal_cells": 300, "abnormal_cells": 1},
    3 : {"normal_cells": 600, "abnormal_cells": 2},
    4 : {"normal_cells": 1200, "abnormal_cells": 3},
    5 : {"normal_cells": 2500, "abnormal_cells": 3},
    6 : {"normal_cells": 4000, "abnormal_cells": 5},
    7 : {"normal_cells": 6000, "abnormal_cells": 7},
    8 : {"normal_cells": 8000, "abnormal_cells": 8},
    9 : {"normal_cells": 10000, "abnormal_cells": 8},
    10: {"normal_cells": 13000, "abnormal_cells": 10}
}