DIFFICULTIES = {
    "easy": {
        "normal_cells": 500,
        "abnormal_cells": 3,
        "world_size": 5000,
    },

    "normal": {
        "normal_cells": 1500,
        "abnormal_cells": 5,
        "world_size": 10000,
    },

    "hard": {
        "normal_cells": 4000,
        "abnormal_cells": 8,
        "world_size": 15000,
    }
}