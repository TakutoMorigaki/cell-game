DIFFICULTIES = {
    "easy": {
        "normal_cells": 500,
        "abnormal_cells": 3,
        "world_size": 5000,
    },

    "normal": {
        "normal_cells": 1500,
        "abnormal_cells": 5,
        "world_size": 10000,
    },

    "hard": {
        "normal_cells": 20000,
        "abnormal_cells": 10,
        "world_size": 100000,
    }
}