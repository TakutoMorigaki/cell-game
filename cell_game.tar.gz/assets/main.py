import os
import pygame
import asyncio
from scenes.menu_scene import MenuScene
from scenes.game_scene import GameScene
from scenes.difficluty_menu_scene import DiffMenuScene
from setting import STAGES
from systems.game_generator import generate_game

def resource_path(relative_path):
    return os.path.join(os.path.abspath("."), relative_path)

pygame.init()

# =========================
# # シーン管理
# =========================

# SCENE_MENU = 0
SCENE_DIFFMENU = 0
SCENE_GAME = 1

current_scene = SCENE_DIFFMENU

# =========================
# 設定
# =========================

WORLD_WIDTH  = 10000
WORLD_HEIGHT = 10000

SCREEN_WIDTH = 1800
SCREEN_HEIGHT = 900

NORMAL_CELL_COUNT = 1000
ABNORMAL_CELL_COUNT = 5

screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
WIDTH, HEIGHT = screen.get_size()

pygame.display.set_caption("細胞診 間違い探し")

# font = pygame.font.Font(resource_path("fonts/NotoSansJP-VariableFont_wght.ttf"), 32)
font = pygame.font.Font(resource_path("fonts/MPLUS1p-Bold.ttf"), 32)
font.set_bold(True)

start_time = 0
clear_time = 0
game_cleared = False


touch_dragging = False
touch_start_pos = (0, 0)
last_touch_pos  = (0, 0)
touch_moved = False

active_touches = {}
pinch_distance = None

# =========================
# 画像読み込み
# =========================

normal_images = [
    pygame.image.load(resource_path("images/normal_1.png")).convert_alpha(),
    pygame.image.load(resource_path("images/normal_2.png")).convert_alpha(),
]

abnormal_images = [
    pygame.image.load(resource_path("images/abnormal_1.png")).convert_alpha(),
    pygame.image.load(resource_path("images/abnormal_2.png")).convert_alpha(),
    pygame.image.load(resource_path("images/abnormal_3.png")).convert_alpha(),
    pygame.image.load(resource_path("images/abnormal_4.png")).convert_alpha(),
    pygame.image.load(resource_path("images/abnormal_5.png")).convert_alpha(),
    pygame.image.load(resource_path("images/abnormal_6.png")).convert_alpha(),
]


clock = pygame.time.Clock()

menu_scene = MenuScene(
    font,
    WIDTH,
    HEIGHT
)

game_scene = None

diff_menu_scene = DiffMenuScene(
    font,
    WIDTH,
    HEIGHT
)

async def main():

    global current_scene
    global NORMAL_CELL_COUNT
    global ABNORMAL_CELL_COUNT
    global cells
    global grid
    global GRID_SIZE
    global WORLD_WIDTH
    global WORLD_HEIGHT
    global WIDTH
    global HEIGHT
    global difficulty

    running = True

    cells = []
    grid = {}
    GRID_SIZE = 80

    # =========================
    # メインループ
    # =========================

    while running:

        WIDTH, HEIGHT = screen.get_size()

        clock.tick(60)

        # if current_scene == SCENE_MENU:
        if current_scene == SCENE_DIFFMENU:
            diff_menu_scene.update_layout(WIDTH, HEIGHT)

        elif current_scene == SCENE_GAME:
            game_scene.update_layout(WIDTH, HEIGHT)

        for event in pygame.event.get():
                
            # if current_scene == SCENE_MENU:
            if current_scene == SCENE_DIFFMENU:

                if event.type == pygame.QUIT:
                    running = False

                # result = menu_scene.handle_event(event)
                result = diff_menu_scene.handle_event(event)

                if result:

                    if result["action"] == "start":

                        # NORMAL_CELL_COUNT = result["normal_count"]
                        # ABNORMAL_CELL_COUNT = result["abnormal_count"]

                        stage = result["stage"]
                        config = STAGES[stage]

                        NORMAL_CELL_COUNT = config["normal_cells"]
                        ABNORMAL_CELL_COUNT = config["abnormal_cells"]

                        cells, grid, GRID_SIZE, WORLD_WIDTH, WORLD_HEIGHT = generate_game(
                            NORMAL_CELL_COUNT,
                            ABNORMAL_CELL_COUNT,
                            normal_images,
                            abnormal_images)

                        game_scene = GameScene(
                            font,
                            WIDTH,
                            ABNORMAL_CELL_COUNT,
                            cells,
                            grid,
                            WORLD_WIDTH,
                            WORLD_HEIGHT
                        )

                        current_scene = SCENE_GAME


            elif current_scene == SCENE_GAME:

                if event.type == pygame.QUIT:
                    running = False

                result = game_scene.handle_event(event, WIDTH, HEIGHT)

                if result == "menu":
                    # current_scene = SCENE_MENU
                    current_scene = SCENE_DIFFMENU


        # -------------------------
        # 描画
        # -------------------------

        # メニュー画面
        # if current_scene == SCENE_MENU:
        if current_scene == SCENE_DIFFMENU:

            # menu_scene.draw(screen)
            diff_menu_scene.draw(screen)


        # ゲーム画面
        elif current_scene == SCENE_GAME:

            game_scene.update()

            game_scene.draw(screen)


        pygame.display.flip()

        await asyncio.sleep(0)

asyncio.run(main())