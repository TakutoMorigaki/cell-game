import os
import sys
import pygame
import random
import math
import time
import asyncio
from objects.cell import Cell
from objects.button import Button
from scenes.menu_scene import MenuScene
from systems.game_generator import generate_game

def resource_path(relative_path):
    return os.path.join(os.path.abspath("."), relative_path)

pygame.init()

# =========================
# # シーン管理
# =========================

SCENE_MENU = 0
SCENE_GAME = 1

current_scene = SCENE_MENU

# =========================
# 設定
# =========================

WORLD_WIDTH  = 10000
WORLD_HEIGHT = 10000

camera_x = 0
camera_y = 0

zoom = 0.2

MINIMAP_WIDTH  = 220
MINIMAP_HEIGHT = 220

MINIMAP_MARGIN = 20

dragging = False

last_mouse_pos = (0, 0)

NORMAL_CELL_COUNT = 100
ABNORMAL_CELL_COUNT = 5

found_count = 0

BACKGROUND = (255, 255, 255)

SCREEN_WIDTH = 1800
SCREEN_HEIGHT = 900

hint_active = False
hint_target = None
hint_timer = 0

giveup_flg = False

# screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.RESIZABLE | pygame.SCALED)
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
WIDTH, HEIGHT = screen.get_size()

pygame.display.set_caption("細胞診 間違い探し")

font = pygame.font.Font(resource_path("fonts/NotoSansJP-VariableFont_wght.ttf"), 32)
# font = pygame.font.SysFont(None, 40)

start_time = 0
clear_time = 0
game_cleared = False


touch_dragging = False
touch_start_pos = (0, 0)
last_touch_pos  = (0, 0)
touch_moved = False

active_touches = {}
pinch_distance = None

# =========================
# 画像読み込み
# =========================

normal_images = [
    pygame.image.load(resource_path("images/normal_1.png")).convert_alpha(),
    pygame.image.load(resource_path("images/normal_2.png")).convert_alpha(),
]

abnormal_images = [
    pygame.image.load(resource_path("images/abnormal_1.png")).convert_alpha(),
    pygame.image.load(resource_path("images/abnormal_2.png")).convert_alpha(),
    pygame.image.load(resource_path("images/abnormal_3.png")).convert_alpha(),
    pygame.image.load(resource_path("images/abnormal_4.png")).convert_alpha(),
    pygame.image.load(resource_path("images/abnormal_5.png")).convert_alpha(),
    pygame.image.load(resource_path("images/abnormal_6.png")).convert_alpha(),
]
# normal_images = [
#     pygame.image.load(resource_path("images/normal_1.png")),
#     pygame.image.load(resource_path("images/normal_2.png")),
# ]

# abnormal_images = [
#     pygame.image.load(resource_path("images/abnormal_1.png")),
#     pygame.image.load(resource_path("images/abnormal_2.png")),
#     pygame.image.load(resource_path("images/abnormal_3.png")),
#     pygame.image.load(resource_path("images/abnormal_4.png")),
#     pygame.image.load(resource_path("images/abnormal_5.png")),
#     pygame.image.load(resource_path("images/abnormal_6.png")),
# ]





# =========================
# ミニマップ描画関数
# =========================
def draw_minimap(screen, cells, camera_x, camera_y, zoom, world_width, world_height):

    minimap_x = WIDTH - MINIMAP_WIDTH - MINIMAP_MARGIN
    minimap_y = HEIGHT - MINIMAP_HEIGHT - MINIMAP_MARGIN

    # 背景
    pygame.draw.rect(
        screen,
        (30, 30, 30),
        (minimap_x, minimap_y,
         MINIMAP_WIDTH, MINIMAP_HEIGHT),
        border_radius=10
    )

    # 枠
    pygame.draw.rect(
        screen,
        (220, 220, 220),
        (minimap_x, minimap_y,
         MINIMAP_WIDTH, MINIMAP_HEIGHT),
        2,
        border_radius=10
    )

    # 細胞描画
    for cell in cells:

        mx = minimap_x + (cell.x / world_width) * MINIMAP_WIDTH
        my = minimap_y + (cell.y / world_height) * MINIMAP_HEIGHT

        if cell.is_target:

            if cell.found:
                color = (255, 0, 0)
            else:
                color = (180, 180, 180)

        else:
            color = (180, 180, 180)

        pygame.draw.circle(
            screen,
            color,
            (int(mx), int(my)),
            2
        )

    # カメラ範囲
    view_w = WIDTH / zoom
    view_h = HEIGHT / zoom

    cam_x = minimap_x + (camera_x / world_width) * MINIMAP_WIDTH
    cam_y = minimap_y + (camera_y / world_height) * MINIMAP_HEIGHT

    cam_w = (view_w / world_width) * MINIMAP_WIDTH
    cam_h = (view_h / world_height) * MINIMAP_HEIGHT

    pygame.draw.rect(
        screen,
        (0, 255, 255),
        (cam_x, cam_y, cam_w, cam_h),
        2
    )

    if hint_active and hint_target:

        hx = minimap_x + (
            hint_target.x / world_width
        ) * MINIMAP_WIDTH

        hy = minimap_y + (
            hint_target.y / world_height
        ) * MINIMAP_HEIGHT

        pygame.draw.circle(
            screen,
            (0, 255, 0),
            (int(hx), int(hy)),
            18,
            3
        )


# =========================
# メッセージ表示
# =========================

message = ""
message_timer = 0

def show_message(text):
    global message, message_timer

    if text == "異常発見!":
        message = text
        message_timer = 120
        return

    if message_timer > 0:
        return
    message = text
    message_timer = 90

# =========================
# 細胞判定
# =========================

def check_cell_click(world_pos):

    global found_count
    global game_cleared
    global clear_time
    global giveup_flg

    if game_cleared or giveup_flg:
        return

    world_x, world_y = world_pos

    gx = int(world_x // GRID_SIZE)
    gy = int(world_y // GRID_SIZE)

    clicked_any = False

    for nx in range(gx - 1, gx + 2):
        for ny in range(gy - 1, gy + 2):

            if (nx, ny) not in grid:
                continue

            for cell in grid[(nx, ny)]:

                if cell.clicked(world_pos):

                    clicked_any = True

                    if cell.is_target and not cell.found:

                        cell.found = True

                        found_count += 1

                        if (
                            found_count == ABNORMAL_CELL_COUNT
                            and not game_cleared
                        ):

                            game_cleared = True

                            clear_time = (
                                time.time() - start_time
                            )

                        show_message("異常発見!")

                    else:
                        show_message("ざんねん...")

                    break

            if clicked_any:
                break

        if clicked_any:
            break

# =========================
# ピンチズーム用関数
# =========================
def get_touch_distance():

    if len(active_touches) < 2:
        return None

    touches = list(active_touches.values())

    x1, y1 = touches[0]
    x2, y2 = touches[1]

    dx = x2 - x1
    dy = y2 - y1

    return math.sqrt(dx * dx + dy * dy)

def get_touch_center():

    if len(active_touches) < 2:
        return None

    touches = list(active_touches.values())

    x1, y1 = touches[0]
    x2, y2 = touches[1]

    center_x = (x1 + x2) / 2
    center_y = (y1 + y2) / 2

    return center_x, center_y


# # =========================
# # ゲーム生成
# # =========================

# def generate_game():

#     global WORLD_WIDTH
#     global WORLD_HEIGHT

#     cells = []

#     GRID_SIZE = 80

#     grid = {}

#     def get_grid_pos(x, y):

#         gx = int(x // GRID_SIZE)
#         gy = int(y // GRID_SIZE)

#         return gx, gy
#     # -------------------------
#     # クラスタ生成
#     # -------------------------

#     #center_x = WORLD_WIDTH // 2
#     #center_y = WORLD_HEIGHT // 2

#     clusters = []

#     if NORMAL_CELL_COUNT <= 1500:
#         WORLD_WIDTH  = 5000
#         WORLD_HEIGHT = 5000

#     elif NORMAL_CELL_COUNT <= 3500:
#         WORLD_WIDTH  = 10000
#         WORLD_HEIGHT = 10000

#     else:
#         WORLD_WIDTH  = 15000
#         WORLD_HEIGHT = 15000

#     CLUSTER_COUNT = 200
#     #GLOBAL_SPREAD = 1800

#     for _ in range(CLUSTER_COUNT):

#         cx = random.uniform(200, WORLD_WIDTH - 200)

#         cy = random.uniform(200, WORLD_HEIGHT - 200)

#         clusters.append((cx, cy))

#     # -------------------------
#     # 細胞配置関数
#     # -------------------------

#     def place_cell(is_target):

#         for _ in range(1000):

#             cluster = random.choice(clusters)

#             if NORMAL_CELL_COUNT <= 1500:
#                 spread = 150

#             elif NORMAL_CELL_COUNT <= 3500:
#                 spread = 300

#             else:
#                 spread = 450

#             x = cluster[0] + random.uniform(-spread, spread)
#             y = cluster[1] + random.uniform(-spread, spread)

#             radius = random.uniform(45, 55)

#             # 画面外防止
#             if (
#                 x - radius < 0 or
#                 x + radius > WORLD_WIDTH or
#                 y - radius < 0 or
#                 y + radius > WORLD_HEIGHT
#             ):
#                 continue

#             overlap = False

#             gx, gy = get_grid_pos(x, y)

#             overlap = False

#             # 周囲9マスだけ調べる
#             for nx in range(gx - 1, gx + 2):
#                 for ny in range(gy - 1, gy + 2):

#                     if (nx, ny) not in grid:
#                         continue

#                     for cell in grid[(nx, ny)]:

#                         dx = x - cell.x
#                         dy = y - cell.y

#                         dist = math.sqrt(dx * dx + dy * dy)

#                         if dist < (radius + cell.radius) * 0.75:

#                             overlap = True
#                             break

#                     if overlap:
#                         break

#                 if overlap:
#                     break

#             if overlap:
#                 continue

#             if is_target:
#                 image = random.choice(abnormal_images)
#             else:
#                 image = random.choice(normal_images)

#             new_cell = Cell(
#                 x,
#                 y,
#                 radius,
#                 image,
#                 is_target
#             )

#             cells.append(new_cell)

#             if (gx, gy) not in grid:
#                 grid[(gx, gy)] = []

#             grid[(gx, gy)].append(new_cell)

#             return
        
#         print(len(cells))

#     # 間違い画像を先に配置
#     for _ in range(ABNORMAL_CELL_COUNT):
#         place_cell(True)

#     # 通常細胞
#     for _ in range(NORMAL_CELL_COUNT):
#         place_cell(False)

#     return cells, grid, GRID_SIZE, WORLD_WIDTH, WORLD_HEIGHT

# normal_minus_button = Button(
#     250, 300, 80, 80, "-", font
# )

# normal_plus_button = Button(
#     550, 300, 80, 80, "+", font
# )

# abnormal_minus_button = Button(
#     250, 420, 80, 80, "-", font
# )

# abnormal_plus_button = Button(
#     550, 420, 80, 80, "+", font
# )


# start_button = Button(
#     WIDTH // 2 - 100,
#     HEIGHT // 2 + 100,
#     200,
#     60,
#     "開始",
#     font
# )

retry_button = Button(
    WIDTH - 220,
    20,
    200,
    60,
    "リトライ",
    font
)

hint_button = Button(
    WIDTH - 220,
    100,
    200,
    60,
    "ヒント",
    font
)

giveup_button = Button(
    WIDTH - 220,
    180,
    200,
    60,
    "諦める",
    font
)

clock = pygame.time.Clock()

menu_scene = MenuScene(
    font,
    WIDTH,
    HEIGHT
)

async def main():
    global dragging
    global last_mouse_pos
    global camera_x
    global camera_y
    global zoom
    global found_count
    global current_scene
    global message_timer
    global game_cleared
    global clear_time
    global start_time
    global touch_dragging
    global touch_start_pos
    global last_touch_pos
    global touch_moved
    global active_touches
    global pinch_distance
    global NORMAL_CELL_COUNT
    global ABNORMAL_CELL_COUNT
    global cells
    global grid
    global GRID_SIZE
    global WORLD_WIDTH
    global WORLD_HEIGHT
    global WIDTH
    global HEIGHT
    global hint_active
    global hint_target
    global hint_timer
    global giveup_flg

    running = True

    cells = []
    grid = {}
    GRID_SIZE = 80

    # =========================
    # メインループ
    # =========================

    while running:

        WIDTH, HEIGHT = screen.get_size()

        clock.tick(60)

        # normal_minus_button.rect = pygame.Rect(
        #     menu_center_x + 80,
        #     HEIGHT // 3,
        #     button_w,
        #     button_h
        # )

        # normal_plus_button.rect = pygame.Rect(
        #     menu_center_x + 200,
        #     HEIGHT // 3,
        #     button_w,
        #     button_h
        # )

        # row_gap = HEIGHT // 7

        # abnormal_minus_button.rect = pygame.Rect(
        #     menu_center_x + 80,
        #     HEIGHT // 3 + row_gap,
        #     button_w,
        #     button_h
        # )

        # abnormal_plus_button.rect = pygame.Rect(
        #     menu_center_x + 200,
        #     HEIGHT // 3 + row_gap,
        #     button_w,
        #     button_h
        # )

        # start_button.rect = pygame.Rect(
        #     WIDTH // 2 -120,
        #     HEIGHT - 180,
        #     240,
        #     80
        # )

        retry_button.rect = pygame.Rect(
            WIDTH - WIDTH // 5,
            20,
            WIDTH // 6,
            HEIGHT // 14
        )

        hint_button.rect = pygame.Rect(
            WIDTH - WIDTH // 5,
            HEIGHT // 10,
            WIDTH // 6,
            HEIGHT // 14
        )

        giveup_button.rect = pygame.Rect(
            WIDTH - WIDTH // 5,
            HEIGHT // 5,
            WIDTH // 6,
            HEIGHT // 14
        )

        for event in pygame.event.get():
                
            if current_scene == SCENE_MENU:

                if event.type == pygame.QUIT:
                    running = False

                result = menu_scene.handle_event(event)

                if result:

                    if result["action"] == "start":

                        NORMAL_CELL_COUNT = result["normal_count"]
                        ABNORMAL_CELL_COUNT = result["abnormal_count"]

                        cells, grid, GRID_SIZE, WORLD_WIDTH, WORLD_HEIGHT = generate_game(
                            NORMAL_CELL_COUNT,
                            ABNORMAL_CELL_COUNT,
                            normal_images,
                            abnormal_images)

                        current_scene = SCENE_GAME

                        found_count = 0
                        game_cleared = False
                        giveup_flg = False

                        start_time = time.time()

                        clear_time = 0


                # elif event.type == pygame.KEYDOWN:

                #     if event.key == pygame.K_UP:
                #         NORMAL_CELL_COUNT += 100

                #     elif event.key == pygame.K_DOWN:
                #         NORMAL_CELL_COUNT = max(
                #             100,
                #             NORMAL_CELL_COUNT - 100
                #         )

                #     elif event.key == pygame.K_RIGHT:
                #         ABNORMAL_CELL_COUNT += 1

                #     elif event.key == pygame.K_LEFT:
                #         ABNORMAL_CELL_COUNT = max(
                #             1,
                #             ABNORMAL_CELL_COUNT - 1
                #         )

                # elif (
                #     event.type == pygame.MOUSEBUTTONDOWN and
                #     event.button == 1
                # ):
                #     if normal_plus_button.clicked(event.pos):

                #         NORMAL_CELL_COUNT += 100

                #     elif normal_minus_button.clicked(event.pos):

                #         NORMAL_CELL_COUNT = max(
                #             100,
                #             NORMAL_CELL_COUNT - 100
                #         )

                #     elif abnormal_plus_button.clicked(event.pos):

                #         ABNORMAL_CELL_COUNT += 1

                #     elif abnormal_minus_button.clicked(event.pos):

                #         ABNORMAL_CELL_COUNT = max(
                #             1,
                #             ABNORMAL_CELL_COUNT - 1
                #         )

                #     elif start_button.clicked(event.pos):

                #         found_count = 0
                #         game_cleared = False
                #         giveup_flg = False

                #         start_time = time.time()

                #         clear_time = 0

                #         cells, grid, GRID_SIZE, WORLD_WIDTH, WORLD_HEIGHT = generate_game()

                #         current_scene = SCENE_GAME

            elif current_scene == SCENE_GAME:

                if event.type == pygame.QUIT:
                    running = False

                elif event.type == pygame.MOUSEBUTTONDOWN:

                    pos = event.pos

                    if event.button == 3:
                        dragging = True
                        last_mouse_pos = event.pos

                    elif event.button == 1:

                        if retry_button.clicked(event.pos):

                            found_count = 0

                            game_cleared = False
                            giveup_flg = False

                            current_scene = SCENE_MENU
                            camera_x = 0
                            camera_y = 0
                            zoom = 0.2

                            continue

                        elif hint_button.clicked(event.pos):

                            unfound = [
                                c for c in cells
                                if c.is_target and not c.found
                            ]

                            if unfound:
                                hint_target = random.choice(unfound)
                                hint_active = True
                                hint_timer = 100

                        elif giveup_button.clicked(event.pos):

                            for cell in cells:
                                if cell.is_target:
                                    cell.found = True

                            clear_time = 0
                            game_cleared = True
                            giveup_flg = True

                        world_x = camera_x + pos[0] / zoom
                        world_y = camera_y + pos[1] / zoom

                        check_cell_click((world_x, world_y))

                elif event.type == pygame.MOUSEBUTTONUP:

                    if event.button == 3:
                        dragging = False

                elif event.type == pygame.MOUSEMOTION:

                    if dragging:

                        dx = event.pos[0] - last_mouse_pos[0]
                        dy = event.pos[1] - last_mouse_pos[1]

                        camera_x -= dx / zoom
                        camera_y -= dy / zoom

                        last_mouse_pos = event.pos

                elif event.type == pygame.MOUSEWHEEL:

                    if event.y > 0:
                        zoom *= 1.1
                    else:
                        zoom /= 1.1

                    zoom = max(0.01, min(zoom, 5.0))

                elif event.type == pygame.FINGERDOWN:

                    touch_moved = False

                    touch_start_pos = (
                        event.x * WIDTH,
                        event.y * HEIGHT
                    )

                    last_touch_pos = touch_start_pos

                    active_touches[event.finger_id] = (
                        event.x * WIDTH,
                        event.y * HEIGHT
                    )

                    if len(active_touches) == 2:

                        pinch_distance = get_touch_distance()

                    touch_dragging = True

                elif event.type == pygame.FINGERMOTION:

                    active_touches[event.finger_id] = (
                        event.x * WIDTH,
                        event.y * HEIGHT
                    )

                    if len(active_touches) >= 2:

                        new_distance = get_touch_distance()
                        touch_moved = True

                        if pinch_distance and new_distance:

                            zoom_ratio = new_distance / pinch_distance

                            old_zoom = zoom

                            center = get_touch_center()

                            if center:

                                center_x, center_y = center

                                world_x = camera_x + center_x / old_zoom
                                world_y = camera_y + center_y / old_zoom

                                zoom *= zoom_ratio

                                zoom = max(0.01, min(zoom, 5.0))

                                camera_x = world_x - center_x / zoom
                                camera_y = world_y - center_y / zoom

                        pinch_distance = new_distance

                    elif touch_dragging:

                        current_pos =(
                            event.x * WIDTH,
                            event.y * HEIGHT
                        )

                        dx = current_pos[0] - last_touch_pos[0]
                        dy = current_pos[1] - last_touch_pos[1]

                        camera_x -= dx / zoom
                        camera_y -= dy / zoom

                        move_dx = (
                            current_pos[0] - touch_start_pos[0]
                        )

                        move_dy = (
                            current_pos[1] - touch_start_pos[1]
                        )

                        move_dist = math.sqrt(
                            move_dx * move_dx +
                            move_dy * move_dy
                        )

                        if move_dist > 15:
                            touch_moved = True

                        last_touch_pos = current_pos

                elif event.type == pygame.FINGERUP:

                    if not touch_moved:

                        screen_x = event.x * WIDTH
                        screen_y = event.y * HEIGHT

                        world_x = camera_x + screen_x / zoom
                        world_y = camera_y + screen_y / zoom

                        check_cell_click((world_x, world_y))

                    touch_dragging = False

                    if event.finger_id in active_touches:
                        del active_touches[event.finger_id]

                    if len(active_touches) < 2:
                        pinch_distance = None


        # -------------------------
        # 描画
        # -------------------------

        # メニュー画面
        if current_scene == SCENE_MENU:

            menu_scene.draw(screen)

            # screen.fill((240, 240, 240))

            # title = font.render(
            #     "細胞診ゲーム",
            #     True,
            #     (0, 0, 0)
            # )

            # title_rect = title.get_rect(
            #     center=(WIDTH // 2, HEIGHT // 6)
            # )
            # screen.blit(title, title_rect)

            # label_y = HEIGHT // 3

            # label = font.render(
            #     "正常細胞数",
            #     True,
            #     (0, 0, 0)
            # )

            # value = font.render(
            #     str(NORMAL_CELL_COUNT),
            #     True,
            #     (0, 0, 0)
            # )

            # label_rect = label.get_rect(
            #     center=(WIDTH // 2 - 220, label_y + 35)
            # )

            # value_rect = value.get_rect(
            #     center=(WIDTH // 2, label_y + 35)
            # )

            # screen.blit(label, label_rect)
            # screen.blit(value, value_rect)

            # abnormal_y = HEIGHT // 3 + row_gap

            # ab_label = font.render(
            #     "異常細胞数",
            #     True,
            #     (0, 0, 0)
            # )

            # ab_value = font.render(
            #     str(ABNORMAL_CELL_COUNT),
            #     True,
            #     (0, 0, 0)
            # )

            # ab_label_rect = ab_label.get_rect(
            #     center=(WIDTH // 2 - 220, abnormal_y + 35)
            # )

            # ab_value_rect = ab_value.get_rect(
            #     center=(WIDTH // 2, abnormal_y + 35)
            # )

            # screen.blit(ab_label, ab_label_rect)
            # screen.blit(ab_value, ab_value_rect)

            # normal_text = font.render(
            #     f"正常細胞数(↑↓キー): {NORMAL_CELL_COUNT}",
            #     True,
            #     (0, 0, 0)
            # )

            # abnormal_text = font.render(
            #     f"異常細胞数(←→キー): {ABNORMAL_CELL_COUNT}",
            #     True,
            #     (0, 0, 0)
            # )

            # normal_rect = normal_text.get_rect(
            #     center=(WIDTH // 2, HEIGHT // 3 + 40)
            # )
            # screen.blit(normal_text, normal_rect)

            # abnormal_rect = abnormal_text.get_rect(
            #     center=(WIDTH // 2, HEIGHT // 3 + 160)
            # )
            # screen.blit(abnormal_text, abnormal_rect)

            # normal_minus_button.draw(screen)
            # normal_plus_button.draw(screen)

            # abnormal_minus_button.draw(screen)
            # abnormal_plus_button.draw(screen)

            # start_button.draw(screen)

        # ゲーム画面
        elif current_scene == SCENE_GAME:

            screen.fill(BACKGROUND)

            for cell in cells:
                cell.draw(
                    screen,
                    camera_x,
                    camera_y,
                    WIDTH,
                    HEIGHT,
                    zoom
                )

            ui_text = font.render(
                f"発見数: {found_count} / {ABNORMAL_CELL_COUNT}",
                True,
                (0, 0, 0)
            )

            cell_num = font.render(
                f"総細胞数: {len(cells)}",
                True,
                (0, 0, 0)
            )

            screen.blit(ui_text, (20, 20))
            screen.blit(cell_num, (20, 60))

            if game_cleared:
                elapsed_time = int(clear_time)
            else:
                elapsed_time = int(time.time() - start_time)

            minutes = elapsed_time // 60
            seconds = elapsed_time % 60

            timer_text = font.render(
                f"時間: {minutes:02}:{seconds:02}",
                True,
                (0, 0, 0)
            )

            screen.blit(timer_text, (20, 100))

            # メッセージ
            if message_timer > 0:

                text = font.render(
                    message,
                    True,
                    (0, 0, 0)
                )

                rect = text.get_rect(center=(WIDTH // 2, 50))

                screen.blit(text, rect)

                message_timer -= 1

            if game_cleared and not giveup_flg:
                clear_text = font.render("クリア！", True, (0, 255, 70))
                screen.blit(clear_text, clear_text.get_rect(center=(WIDTH // 2, 100)))

                minutes = int(clear_time // 60)
                seconds = int(clear_time % 60)

                time_text = font.render(
                    f"クリアタイム {minutes}分 {seconds}秒",
                    True,
                    (0, 0, 0)
                )

                screen.blit(
                    time_text,
                    time_text.get_rect(center=(WIDTH // 2, 160))
                )

            elif giveup_flg:
                giveup_text = font.render("ギブアップ...", True, (255, 0, 0))
                screen.blit(giveup_text, giveup_text.get_rect(center=(WIDTH // 2, 100)))


            retry_button.draw(screen)

            hint_button.draw(screen)

            giveup_button.draw(screen)

            draw_minimap(
                screen,
                cells,
                camera_x,
                camera_y,
                zoom,
                WORLD_WIDTH,
                WORLD_HEIGHT
            )

        if hint_timer > 0:
            hint_timer -= 1
        else:
            hint_active = False
            hint_target = None

        pygame.display.flip()

        await asyncio.sleep(0)

asyncio.run(main())