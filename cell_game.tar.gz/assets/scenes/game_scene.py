import pygame
import random
import math
import time
import os
from objects.button import Button

def resource_path(relative_path):
    return os.path.join(os.path.abspath("."), relative_path)

class GameScene:

    def __init__(self, font, width, abnormal_cell_count, cells, grid, world_width, world_height):

        self.font = font

        self.camera_x = 0
        self.camera_y = 0

        self.zoom = 0.2

        self.dragging = False
        self.last_mouse_pos = (0, 0)

        self.touch_dragging = False
        self.touch_start_pos = (0, 0)
        self.last_touch_pos = (0, 0)
        self.touch_moved = False

        self.active_touches = {}
        self.pinch_distance = None

        self.found_count = 0
        self.game_cleared = False
        self.giveup_flg = False

        self.hint_active = False
        self.hint_target = None
        self.hint_timer = 0
        self.total_hint = 0

        self.message = ""
        self.message_timer = 0

        self.grid = grid
        self.grid_size = 80

        self.cells = cells

        self.abnormal_cell_count = abnormal_cell_count

        self.start_time = time.time()
        self.clear_time = 0

        self.world_width = world_width
        self.world_height = world_height

        self.minimap_width  = 220
        self.minimap_height = 220

        self.minimap_x = 0
        self.minimap_y = 0

        self.minimap_margin = 20

        self.last_click_time = 0

        self.confirm_giveup = False


        self.retry_button = Button(
            width - 220,
            20,
            200,
            60,
            "タイトルへ",
            font
        )

        self.hint_button = Button(
            width- 220,
            100,
            200,
            60,
            "ヒント",
            font
        )

        self.giveup_button = Button(
            width - 220,
            180,
            200,
            60,
            "諦める",
            font
        )

        self.correct_sound = pygame.mixer.Sound(
            resource_path("sounds/correct.ogg")
        )

        self.miss_sound = pygame.mixer.Sound(
            resource_path("sounds/miss.ogg")
        )

    def update_layout(self, width, height):

        self.retry_button.rect = pygame.Rect(
            width - width // 5,
            20,
            width // 6,
            height // 14
        )

        self.hint_button.rect = pygame.Rect(
            self.minimap_x,
            self.minimap_y - 80,
            self.minimap_width,
            60
        )

        self.giveup_button.rect = pygame.Rect(
            width - width // 5,
            height // 10,
            width // 6,
            height // 14
        )

    def handle_event(self, event, width, height):

        if event.type == pygame.MOUSEBUTTONDOWN:

            pos = event.pos

            if event.button == 3:
                self.dragging = True
                self.last_mouse_pos = event.pos

            elif event.button == 1:

                if self.retry_button.clicked(event.pos):

                    self.found_count = 0

                    self.game_cleared = False
                    self.giveup_flg = False

                    self.camera_x = 0
                    self.camera_y = 0
                    self.zoom = 0.2

                    return "menu"

                elif self.hint_button.clicked(event.pos):

                    if not self.game_cleared and not self.giveup_flg:
                        self.total_hint += 1

                    unfound = [
                        c for c in self.cells
                        if c.is_target and not c.found
                    ]

                    if unfound:
                        self.hint_target = random.choice(unfound)
                        self.hint_active = True
                        self.hint_timer = 100

                elif self.giveup_button.clicked(event.pos):

                    if not self.game_cleared:

                        if not self.confirm_giveup:

                            self.confirm_giveup = True
                            self.show_message("もう一度押すとギブアップ")

                        else:

                            for cell in self.cells:
                                if cell.is_target:
                                    cell.found = True

                            self.clear_time = 0
                            self.game_cleared = True
                            self.giveup_flg = True

                            self.confirm_giveup = False

                    return

                world_x = self.camera_x + pos[0] / self.zoom
                world_y = self.camera_y + pos[1] / self.zoom

                self.check_cell_click((world_x, world_y))

        elif event.type == pygame.MOUSEBUTTONUP:

            if event.button == 3:
                self.dragging = False

        elif event.type == pygame.MOUSEMOTION:

            if self.dragging:

                dx = event.pos[0] - self.last_mouse_pos[0]
                dy = event.pos[1] - self.last_mouse_pos[1]

                self.camera_x -= dx / self.zoom
                self.camera_y -= dy / self.zoom

                self.last_mouse_pos = event.pos

        elif event.type == pygame.MOUSEWHEEL:

            if event.y > 0:
                self.zoom *= 1.1
            else:
                self.zoom /= 1.1

            self.zoom = max(0.1, min(self.zoom, 2.0))

        elif event.type == pygame.FINGERDOWN:

            self.touch_moved = False

            self.touch_start_pos = (
                event.x * width,
                event.y * height
            )

            self.last_touch_pos = self.touch_start_pos

            self.active_touches[event.finger_id] = (
                event.x * width,
                event.y * height
            )

            if len(self.active_touches) == 2:

                self.pinch_distance = self.get_touch_distance()

            self.touch_dragging = True

        elif event.type == pygame.FINGERMOTION:

            self.active_touches[event.finger_id] = (
                event.x * width,
                event.y * height
            )

            if len(self.active_touches) >= 2:

                new_distance = self.get_touch_distance()
                self.touch_moved = True

                if self.pinch_distance and new_distance:

                    zoom_ratio = new_distance / self.pinch_distance

                    old_zoom = self.zoom

                    center = self.get_touch_center()

                    if center:

                        center_x, center_y = center

                        world_x = self.camera_x + center_x / old_zoom
                        world_y = self.camera_y + center_y / old_zoom

                        self.zoom *= zoom_ratio

                        self.zoom = max(0.1, min(self.zoom, 1.5))

                        self.camera_x = world_x - center_x / self.zoom
                        self.camera_y = world_y - center_y / self.zoom

                self.pinch_distance = new_distance

            elif self.touch_dragging:

                current_pos =(
                    event.x * width,
                    event.y * height
                )

                dx = current_pos[0] - self.last_touch_pos[0]
                dy = current_pos[1] - self.last_touch_pos[1]

                self.camera_x -= dx / self.zoom
                self.camera_y -= dy / self.zoom

                move_dx = (
                    current_pos[0] - self.touch_start_pos[0]
                )

                move_dy = (
                    current_pos[1] - self.touch_start_pos[1]
                )

                move_dist = math.sqrt(
                    move_dx * move_dx +
                    move_dy * move_dy
                )

                if move_dist > 15:
                    self.touch_moved = True

                self.last_touch_pos = current_pos

        elif event.type == pygame.FINGERUP:

            if not self.touch_moved:

                screen_x = event.x * width
                screen_y = event.y * height

                world_x = self.camera_x + screen_x / self.zoom
                world_y = self.camera_y + screen_y / self.zoom

                self.check_cell_click((world_x, world_y))

            self.touch_dragging = False

            if event.finger_id in self.active_touches:
                del self.active_touches[event.finger_id]

            if len(self.active_touches) < 2:
                self.pinch_distance = None



    def update(self):
        if self.hint_timer > 0:

            self.hint_timer -= 1

        else:

            self.hint_active = False
            self.hint_target = None

        if self.message_timer > 0:

            self.message_timer -= 1

    def draw(self, screen):

        width, height = screen.get_size()

        screen.fill((255, 255, 255))

        view_left = self.camera_x
        view_top = self.camera_y

        view_right = self.camera_x + width / self.zoom
        view_bottom = self.camera_y + height / self.zoom

        grid_left = int(view_left // self.grid_size)
        grid_right = int(view_right // self.grid_size)

        grid_top = int(view_top // self.grid_size)
        grid_bottom = int(view_bottom // self.grid_size)


        for gx in range(grid_left, grid_right + 1):
            for gy in range(grid_top, grid_bottom + 1):

                if (gx, gy) not in self.grid:
                    continue

                for cell in self.grid[(gx, gy)]:

                    cell.draw(
                        screen,
                        self.camera_x,
                        self.camera_y,
                        width,
                        height,
                        self.zoom
                    )

        ui_text = self.font.render(
            f"発見数: {self.found_count} / {self.abnormal_cell_count}",
            True,
            (0, 0, 0)
        )

        cell_num = self.font.render(
            f"総細胞数: {len(self.cells)}",
            True,
            (0, 0, 0)
        )

        screen.blit(ui_text, (20, 20))
        screen.blit(cell_num, (20, 60))

        if self.game_cleared:
            elapsed_time = int(self.clear_time)
        else:
            elapsed_time = int(time.time() - self.start_time)

        minutes = elapsed_time // 60
        seconds = elapsed_time % 60

        timer_text = self.font.render(
            f"時間: {minutes:02}:{seconds:02}",
            True,
            (0, 0, 0)
        )

        screen.blit(timer_text, (20, 100))

        # メッセージ
        if self.message_timer > 0:

            text = self.font.render(
                self.message,
                True,
                (0, 0, 0)
            )

            rect = text.get_rect(center=(width // 2, 50))

            screen.blit(text, rect)

        if self.game_cleared and not self.giveup_flg:
            clear_text = f"クリア！ ヒント利用回数: {self.total_hint}回"

            c_text = self.font.render(
                clear_text,
                True,
                (0, 255, 0)
                )
            
            c_outline = self.font.render(
                clear_text,
                True,
                (0, 0, 0)
            )

            rect = c_text.get_rect(center=(width // 2, 100))

            for dx, dy in [
                (-2, 0), (2, 0),
                (0, -2), (0, 2),
                (-2, -2), (-2, 2),
                (2, -2), (2, 2)
            ]:
                screen.blit(c_outline, rect.move(dx, dy))
            
            screen.blit(c_text, rect)

            minutes = int(self.clear_time // 60)
            seconds = int(self.clear_time % 60)

            time_text = self.font.render(
                f"クリアタイム {minutes}分 {seconds}秒",
                True,
                (0, 0, 0)
            )

            screen.blit(
                time_text,
                time_text.get_rect(center=(width // 2, 160))
            )

            if (
                self.abnormal_cell_count == 10
                and self.total_hint == 0
            ):
                code_text = self.font.render(
                    "EXTRA CODE: CELL-9384",
                    True,
                    (255, 0, 255)
                )

                screen.blit(
                    code_text,
                    code_text.get_rect(
                        center=(width // 2, 220)
                    )
                )

        elif self.giveup_flg:
            giveup_text = self.font.render("ギブアップ...", True, (255, 0, 0))
            screen.blit(giveup_text, giveup_text.get_rect(center=(width // 2, 100)))


        self.retry_button.draw(screen)

        self.hint_button.draw(screen)

        self.giveup_button.draw(screen)

        self.draw_minimap(screen, width, height)


    # =========================
    # メッセージ表示
    # =========================

    def show_message(self, text):

        if text == "異常発見!":
            self.message = text
            self.message_timer = 120
            return

        if self.message_timer > 0:
            return
        self.message = text
        self.message_timer = 90

    # =========================
    # 細胞判定
    # =========================

    def check_cell_click(self, world_pos):

        now = pygame.time.get_ticks()
        self.confirm_giveup = False

        if now - self.last_click_time < 500:
            return
    
        self.last_click_time = now

        if self.game_cleared or self.giveup_flg:
            return

        world_x, world_y = world_pos

        gx = int(world_x // self.grid_size)
        gy = int(world_y // self.grid_size)

        clicked_any = False

        for nx in range(gx - 1, gx + 2):
            for ny in range(gy - 1, gy + 2):

                if (nx, ny) not in self.grid:
                    continue

                for cell in self.grid[(nx, ny)]:

                    if cell.clicked(world_pos):

                        clicked_any = True

                        if cell.is_target and not cell.found:

                            cell.found = True

                            self.correct_sound.play()

                            self.found_count += 1

                            if (
                                self.found_count == self.abnormal_cell_count
                                and not self.game_cleared
                            ):

                                self.game_cleared = True

                                self.clear_time = (
                                    time.time() - self.start_time
                                )

                            self.show_message("異常発見!")

                        else:
                            # self.miss_sound.play()

                            self.show_message("ざんねん...")

                        break

                if clicked_any:
                    break

            if clicked_any:
                break

    # =========================
    # ピンチズーム用関数
    # =========================
    def get_touch_distance(self):

        if len(self.active_touches) < 2:
            return None

        touches = list(self.active_touches.values())

        x1, y1 = touches[0]
        x2, y2 = touches[1]

        dx = x2 - x1
        dy = y2 - y1

        return math.sqrt(dx * dx + dy * dy)

    def get_touch_center(self):

        if len(self.active_touches) < 2:
            return None

        touches = list(self.active_touches.values())

        x1, y1 = touches[0]
        x2, y2 = touches[1]

        center_x = (x1 + x2) / 2
        center_y = (y1 + y2) / 2

        return center_x, center_y

    # =========================
    # ミニマップ描画関数
    # =========================
    def draw_minimap(self, screen, width, height):

        self.minimap_x = width - self.minimap_width - self.minimap_margin
        self.minimap_y = height - self.minimap_height - self.minimap_margin

        # 背景
        pygame.draw.rect(
            screen,
            (30, 30, 30),
            (self.minimap_x, self.minimap_y,
            self.minimap_width, self.minimap_height),
            border_radius=10
        )

        # 枠
        pygame.draw.rect(
            screen,
            (220, 220, 220),
            (self.minimap_x, self.minimap_y,
            self.minimap_width, self.minimap_height),
            2,
            border_radius=10
        )

        # 細胞描画
        for cell in self.cells:

            mx = self.minimap_x + (cell.x / self.world_width) * self.minimap_width
            my = self.minimap_y + (cell.y / self.world_height) * self.minimap_height

            if cell.is_target:

                if cell.found:
                    color = (255, 0, 0)
                else:
                    color = (180, 180, 180)

            else:
                color = (180, 180, 180)

            pygame.draw.circle(
                screen,
                color,
                (int(mx), int(my)),
                2
            )

        # カメラ範囲
        view_w = width / self.zoom
        view_h = height / self.zoom

        cam_x = self.minimap_x + (self.camera_x / self.world_width) * self.minimap_width
        cam_y = self.minimap_y + (self.camera_y / self.world_height) * self.minimap_height

        cam_w = (view_w / self.world_width) * self.minimap_width
        cam_h = (view_h / self.world_height) * self.minimap_height

        pygame.draw.rect(
            screen,
            (0, 255, 255),
            (cam_x, cam_y, cam_w, cam_h),
            2
        )

        if self.hint_active and self.hint_target:

            hx = self.minimap_x + (
                self.hint_target.x / self.world_width
            ) * self.minimap_width

            hy = self.minimap_y + (
                self.hint_target.y / self.world_height
            ) * self.minimap_height

            pygame.draw.circle(
                screen,
                (0, 255, 0),
                (int(hx), int(hy)),
                18,
                3
            )
