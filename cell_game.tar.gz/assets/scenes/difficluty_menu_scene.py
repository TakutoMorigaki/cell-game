import pygame

from objects.button import Button

class DiffMenuScene:

    def __init__(self, font, width, height):

        self.font = font

        self.stage_buttons = []

        for i in range(10):
            button = Button(
                0,
                0,
                180, 80,
                f"STAGE {i+1}",
                font
            )
            self.stage_buttons.append(button)

        self.selected_stage = 1

        self.start_button = Button(
            width // 2 - 100,
            height // 2 + 100,
            200,
            60,
            "開始",
            font
        )



    def update_layout(self, width, height):

        button_w = 180
        button_h = 80

        gap_x = 30
        gap_y = 40

        start_x = width // 2 - (button_w * 5 + gap_x * 4) // 2
        start_y = height // 2 - 100

        for i, button in enumerate(self.stage_buttons):

            row = i // 5
            col = i % 5

            x = start_x + col * (button_w + gap_x)
            y = start_y + row * (button_h + gap_y)

            button.rect = pygame.Rect(
                x,
                y,
                button_w,
                button_h
            )


        self.start_button.rect = pygame.Rect(
            width // 2 - 120,
            height - 180,
            240,
            80
        )



    def handle_event(self, event):

        if (
            event.type == pygame.MOUSEBUTTONDOWN and
            event.button == 1
        ):

            for i, button in enumerate(self.stage_buttons):

                if button.clicked(event.pos):
                    self.selected_stage = i + 1
                    return None

            if self.start_button.clicked(event.pos):

                return {
                    "action": "start",
                    "stage": self.selected_stage
                }

            return None

    def update(self):
        pass

    def draw(self, screen):

        width, height = screen.get_size()

        self.update_layout(width, height)

        screen.fill((255, 255, 255))

        title = self.font.render(
            "細胞診ゲーム",
            True,
            (0, 0, 0)
        )

        title_rect = title.get_rect(
            center=(width // 2, height // 6)
        )

        screen.blit(title, title_rect)

        for i, button in enumerate(self.stage_buttons):

            if self.selected_stage == i + 1:
                color = (100, 200, 255)
            else:
                color = (220, 220, 220)

            button.draw(screen, color)

        self.start_button.draw(screen)
