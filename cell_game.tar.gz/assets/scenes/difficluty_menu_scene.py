import pygame

from objects.button import Button

class DiffMenuScene:

    def __init__(self, font, width, height):

        self.font = font

        self.selected_difficulty = "easy"

        self.easy_button = Button(
            width // 2 - 600,
            height // 2 + 200,
            250,
            60,
            "EASY",
            font
        )

        self.normal_button = Button(
            width // 2 - 125,
            height // 2 + 200,
            250,
            60,
            "NORMAL",
            font
        )

        self.hard_button = Button(
            width // 2 + 350,
            height // 2 + 200,
            250,
            60,
            "HARD",
            font
        )


        self.start_button = Button(
            width // 2 - 100,
            height // 2 + 100,
            200,
            60,
            "開始",
            font
        )



    def update_layout(self, width, height):

        # button_w = max(80, width // 12)
        # button_h = max(60, height // 14)

        self.easy_button.rect = pygame.Rect(
            width // 2 - 600,
            height // 2,
            250,
            80
        )

        self.normal_button.rect = pygame.Rect(
            width // 2 - 125,
            height // 2,
            250,
            80
        )

        self.hard_button.rect = pygame.Rect(
            width // 2 + 350,
            height // 2,
            250,
            80
        )

        self.start_button.rect = pygame.Rect(
            width // 2 - 120,
            height - 180,
            240,
            80
        )



    def handle_event(self, event):

        if (
            event.type == pygame.MOUSEBUTTONDOWN and
            event.button == 1
        ):

            if self.easy_button.clicked(event.pos):
                self.selected_difficulty = "easy"

            elif self.normal_button.clicked(event.pos):
                self.selected_difficulty = "normal"

            elif self.hard_button.clicked(event.pos):
                self.selected_difficulty = "hard"

            elif self.start_button.clicked(event.pos):

                return {
                    "action": "start",
                    "difficulty": self.selected_difficulty
                }
            
            return None

    def update(self):
        pass

    def draw(self, screen):

        width, height = screen.get_size()

        self.update_layout(width, height)

        screen.fill((255, 255, 255))

        title = self.font.render(
            "細胞診ゲーム",
            True,
            (0, 0, 0)
        )

        title_rect = title.get_rect(
            center=(width // 2, height // 6)
        )

        screen.blit(title, title_rect)

        if self.selected_difficulty == "easy":
            easy_color = (100, 255, 100)
        else:
            easy_color = (220, 220, 220)

        if self.selected_difficulty == "normal":
            normal_color = (100, 200, 255)
        else:
            normal_color = (220, 220, 220)

        if self.selected_difficulty == "hard":
            hard_color = (255, 120, 120)
        else:
            hard_color = (220, 220, 220)

        self.easy_button.draw(screen, easy_color)
        self.normal_button.draw(screen, normal_color)
        self.hard_button.draw(screen, hard_color)

        

        self.start_button.draw(screen)
